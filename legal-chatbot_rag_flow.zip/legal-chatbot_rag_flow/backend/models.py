# models.py
from pydantic import BaseModel
from typing import Optional, List, Any

class ChatRequest(BaseModel):
    user_id: Optional[str]
    session_id: Optional[str]
    message: str

class ChatResponse(BaseModel):
    session_id: str
    answer: str
    sources: Optional[List[Any]] = []

class UploadResponse(BaseModel):
    status: str
    message: str
    user_namespace: str
