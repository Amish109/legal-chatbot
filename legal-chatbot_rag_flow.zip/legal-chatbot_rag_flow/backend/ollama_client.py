# ollama_client.py
import os
import json
import requests
import subprocess
from typing import List, Dict, Optional
import shlex
import time

class OllamaClient:
    """
    Minimal wrapper to call local Ollama. Two modes attempted:
     1) HTTP API at http://localhost:11434/api/generate
     2) CLI fallback using `ollama` binary
    The exact model name should match your local Ollama model.
    """

    def __init__(self, model: str = "llama2", base_url: str = "http://localhost:11434"):
        self.model = model
        self.base_url = os.environ.get("OLLAMA_API_URL", base_url)
        self.api_generate = f"{self.base_url}/api/generate"
        self.cli_path = os.environ.get("OLLAMA_CLI", "ollama")

    def ping(self) -> bool:
        try:
            resp = requests.get(self.base_url, timeout=1.5)
            return resp.status_code == 200 or True
        except Exception:
            # try CLI ping
            try:
                subprocess.run([self.cli_path, "version"], capture_output=True, timeout=2)
                return True
            except Exception:
                return False

    def chat(self, system: str, messages: List[Dict[str, str]], temperature: float = 0.0, max_tokens: int = 1000) -> str:
        """
        messages: list of {"role": "user"|"assistant"|"system", "content": "..."}
        For HTTP, we'll create a single prompt by concatenating system + messages.
        """
        # try HTTP first
        try:
            prompt = self._build_prompt(system, messages)
            payload = {
                "model": self.model,
                "prompt": prompt,
                "max_tokens": max_tokens,
                "temperature": temperature
            }
            headers = {"Content-Type": "application/json"}
            r = requests.post(self.api_generate, json=payload, headers=headers, timeout=30)
            if r.ok:
                data = r.json()
                # best-effort to extract generated text
                if isinstance(data, dict):
                    # Ollama returns content in different shapes; try common keys
                    if "text" in data:
                        return data["text"]
                    if "response" in data:
                        return data["response"]
                    # fallback to string
                    return json.dumps(data)
                else:
                    return str(data)
        except Exception:
            pass

        # fallback: CLI approach (ollama generate)
        try:
            prompt = self._build_prompt(system, messages)
            # Using ollama CLI generate model --json --prompt "<prompt>"
            # We'll call: ollama generate <model> --prompt "<prompt>"
            cmd = [self.cli_path, "generate", self.model, "--prompt", prompt]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if proc.returncode == 0:
                return proc.stdout.strip()
            else:
                return proc.stdout.strip() or proc.stderr.strip()
        except Exception as e:
            return f"[ollama_error] {str(e)}"

    def _build_prompt(self, system, messages):
        parts = []
        if system:
            parts.append(f"SYSTEM: {system.strip()}\n")
        for m in messages:
            role = m.get("role", "user").upper()
            parts.append(f"{role}: {m.get('content','').strip()}\n")
        return "\n".join(parts)
