# main.py
import os
import uuid
import shutil
from fastapi import FastAPI, File, UploadFile, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import Optional
from pydantic import BaseModel
from ollama_client import OllamaClient
from embedding import Embedder
from vectorstore import VectorStore
from parsers import extract_text_from_file
from rag import RAG
from ethical import EthicalFilter, EthicalException
from session_store import SessionStore
from models import ChatRequest, ChatResponse, UploadResponse

DATA_DIR = os.environ.get("DATA_DIR", "./data")
os.makedirs(DATA_DIR, exist_ok=True)

app = FastAPI(title="LegalAssistant (FastAPI + Ollama + FAISS)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components (singletons)
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama2")  # change to the model you have
ollama = OllamaClient(model=OLLAMA_MODEL)
embedder = Embedder()
vector_store = VectorStore(base_dir=DATA_DIR, embedding_dim=embedder.dim)
# Two namespaces: 'global' and 'user:{user_id}'
# Session store (Redis optional)
session_store = SessionStore()
# Ethical filter
ethical = EthicalFilter(ollama_client=ollama)

# RAG orchestrator
rag = RAG(ollama_client=ollama, embedder=embedder, vector_store=vector_store, ethical_filter=ethical)


@app.exception_handler(EthicalException)
async def ethical_exc_handler(request: Request, exc: EthicalException):
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.post("/upload", response_model=UploadResponse)
async def upload_document(user_id: str, file: UploadFile = File(...)):
    """
    Upload a user document (pdf/docx/txt). Extracts text, creates embeddings,
    stores in vectorstore under namespace user:{user_id}
    """
    if file.content_type not in ("application/pdf", "text/plain", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword"):
        # allow docx and txt and pdf
        pass

    user_ns = f"user:{user_id}"
    tmp_dir = os.path.join(DATA_DIR, "uploads", user_id)
    os.makedirs(tmp_dir, exist_ok=True)
    file_path = os.path.join(tmp_dir, f"{uuid.uuid4().hex}_{file.filename}")
    with open(file_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    text = extract_text_from_file(file_path)
    if not text or len(text.strip()) < 20:
        raise HTTPException(status_code=400, detail="Could not extract usable text from file.")

    # chunk text simply
    from utils import chunk_text
    chunks = chunk_text(text, max_chars=1500)

    docs = []
    for i, chunk in enumerate(chunks):
        docs.append({
            "id": f"{uuid.uuid4().hex}",
            "text": chunk,
            "meta": {"source": file.filename, "part": i, "user_id": user_id}
        })

    vector_store.add_documents(namespace=user_ns, documents=docs, embedder=embedder)

    return UploadResponse(status="success", message=f"Uploaded and indexed {len(docs)} chunks", user_namespace=user_ns)


@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest):
    """
    Main chat route. Handles session context, ethical filtering, chooses KB (user doc vs global),
    performs RAG and returns the assistant response.
    """
    # Basic safety / ethical filter
    decision = ethical.check_text(req.message)
    if decision.block:
        raise EthicalException(decision.reason)

    session_id = req.session_id or str(uuid.uuid4())
    # append to session history
    session_store.append_message(session_id, {"role": "user", "content": req.message})

    # Decide knowledge base to use: if user has docs and query references uploaded docs, use user namespace
    # We'll perform a quick retrieval from user namespace; if results above threshold, use that
    user_ns = f"user:{req.user_id}" if req.user_id else None
    use_user_kb = False
    retrieved_docs = []
    if user_ns:
        retrieved_docs = vector_store.search(namespace=user_ns, query=req.message, top_k=5)
        # simple heuristic: if any doc has score < threshold (distance small), use it
        if len(retrieved_docs) > 0 and retrieved_docs[0]["score"] < 0.5:
            use_user_kb = True

    kb_namespace = user_ns if use_user_kb else "global"

    # RAG pipeline
    answer, used_docs = rag.answer(query=req.message, session_id=session_id, namespace=kb_namespace)

    # store assistant response in session
    session_store.append_message(session_id, {"role": "assistant", "content": answer})

    return ChatResponse(session_id=session_id, answer=answer, sources=used_docs)


@app.get("/session/{session_id}/history")
async def get_session_history(session_id: str):
    return {"session_id": session_id, "history": session_store.get_history(session_id)}


@app.post("/kb/build_global")
async def build_global_kb(folder_path: str):
    """
    Ingest a folder of plain text files (legal texts: IPC, CrPC, Contracts, etc.) into 'global' KB.
    Each file will be chunked and embedded.
    """
    if not os.path.isdir(folder_path):
        raise HTTPException(status_code=400, detail="folder_path must be a directory containing text files.")

    # iterate files
    all_docs = []
    for fn in os.listdir(folder_path):
        fpath = os.path.join(folder_path, fn)
        if not os.path.isfile(fpath):
            continue
        try:
            text = extract_text_from_file(fpath)
        except Exception as e:
            continue
        if not text:
            continue
        from utils import chunk_text
        chunks = chunk_text(text, max_chars=1500)
        for i, c in enumerate(chunks):
            all_docs.append({
                "id": f"{uuid.uuid4().hex}",
                "text": c,
                "meta": {"source": fn, "part": i}
            })
    if not all_docs:
        raise HTTPException(status_code=400, detail="No documents to ingest.")
    vector_store.add_documents(namespace="global", documents=all_docs, embedder=embedder)
    return {"status": "success", "ingested_docs": len(all_docs)}


@app.get("/health")
async def health():
    return {"status": "ok", "ollama_ok": ollama.ping()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
