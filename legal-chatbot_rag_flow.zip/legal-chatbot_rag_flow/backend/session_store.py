# session_store.py
import os
import redis
import json
import time

class SessionStore:
    """
    Stores session conversation history. Uses Redis if REDIS_URL is provided,
    otherwise uses a simple in-memory dict (non-persistent).
    """

    def __init__(self):
        self.redis_url = os.environ.get("REDIS_URL")
        if self.redis_url:
            self.r = redis.from_url(self.redis_url)
        else:
            self.r = None
            self.memory = {}  # session_id -> list of messages

    def append_message(self, session_id: str, message: dict):
        if self.r:
            key = f"session:{session_id}:history"
            self.r.rpush(key, json.dumps(message))
            # optional TTL of 7 days
            self.r.expire(key, 60 * 60 * 24 * 7)
        else:
            self.memory.setdefault(session_id, []).append(message)
            # no TTL

    def get_history(self, session_id: str):
        if self.r:
            key = f"session:{session_id}:history"
            raw = self.r.lrange(key, 0, -1)
            return [json.loads(x) for x in raw]
        else:
            return self.memory.get(session_id, [])
