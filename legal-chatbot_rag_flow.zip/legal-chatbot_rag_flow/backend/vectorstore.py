# vectorstore.py
import os
import faiss
import numpy as np
import json
from typing import List, Dict, Any
import sqlite3
import threading

# Each namespace has its own FAISS index file and metadata sqlite table
# For simplicity we'll store metadatas in a single sqlite DB keyed by namespace

class VectorStore:
    def __init__(self, base_dir="./data", embedding_dim=384):
        self.base_dir = base_dir
        os.makedirs(self.base_dir, exist_ok=True)
        self.embedding_dim = embedding_dim
        self.index_locks = {}
        # sqlite for metadata
        self.db_path = os.path.join(self.base_dir, "metadb.sqlite")
        self._init_db()
        self._load_index_list()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS docs (
                id TEXT PRIMARY KEY,
                namespace TEXT,
                embedding_index INTEGER,
                text TEXT,
                meta TEXT
            )
        """)
        conn.commit()
        conn.close()

    def _load_index_list(self):
        # ensure index lock dict entry for global namespace
        self.index_locks = {}

    def _get_index_path(self, namespace):
        safe = namespace.replace(":", "_")
        return os.path.join(self.base_dir, f"faiss_{safe}.index")

    def _get_meta_count(self, namespace):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM docs WHERE namespace=?", (namespace,))
        r = c.fetchone()[0]
        conn.close()
        return r

    def _get_lock(self, namespace):
        if namespace not in self.index_locks:
            self.index_locks[namespace] = threading.Lock()
        return self.index_locks[namespace]

    def _load_or_create_index(self, namespace):
        path = self._get_index_path(namespace)
        lock = self._get_lock(namespace)
        with lock:
            if os.path.exists(path):
                idx = faiss.read_index(path)
            else:
                idx = faiss.IndexFlatIP(self.embedding_dim)  # use inner product with normalized vectors
                faiss.write_index(idx, path)
            return idx

    def _save_index(self, namespace, index):
        path = self._get_index_path(namespace)
        faiss.write_index(index, path)

    def add_documents(self, namespace: str, documents: List[Dict[str, Any]], embedder):
        """
        documents = [{"id": "...", "text": "...", "meta": {...}}, ...]
        embedder: Embedder instance
        """
        texts = [d["text"] for d in documents]
        embs = embedder.embed(texts)
        # normalize for inner product similarity
        norms = np.linalg.norm(embs, axis=1, keepdims=True)
        norms[norms==0] = 1
        embs = embs / norms

        idx = self._load_or_create_index(namespace)
        with self._get_lock(namespace):
            # Append embeddings
            if isinstance(idx, faiss.IndexFlatIP):
                idx.add(embs.astype("float32"))
            else:
                idx.add(embs.astype("float32"))
            # Save index
            self._save_index(namespace, idx)
            # Insert metadata into sqlite
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            # compute current count to map embedding_index positions
            current_count = self._get_meta_count(namespace)
            for i, doc in enumerate(documents):
                embedding_index = current_count + i
                c.execute("INSERT INTO docs (id, namespace, embedding_index, text, meta) VALUES (?, ?, ?, ?, ?)",
                          (doc["id"], namespace, embedding_index, doc["text"], json.dumps(doc.get("meta", {}))))
            conn.commit()
            conn.close()

    def search(self, namespace: str, query: str = None, query_emb: np.ndarray = None, top_k: int = 5):
        """
        Return list of {id, text, meta, score}
        query_emb: if provided, must be normalized
        """
        if query_emb is None:
            raise ValueError("query_emb required (pre-embed with the embedder)")

        idx = self._load_or_create_index(namespace)
        q = query_emb.astype("float32").reshape(1, -1)
        # inner product scores
        D, I = idx.search(q, top_k)
        ids = I[0].tolist()
        scores = D[0].tolist()
        results = []
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        for ii, sc in zip(ids, scores):
            if ii == -1:
                continue
            c.execute("SELECT id, text, meta FROM docs WHERE namespace=? AND embedding_index=?", (namespace, ii))
            row = c.fetchone()
            if not row:
                continue
            doc_id, text, meta = row
            try:
                meta_obj = json.loads(meta)
            except Exception:
                meta_obj = {}
            results.append({"id": doc_id, "text": text, "meta": meta_obj, "score": float(1.0 - sc) if False else float(1.0 - sc)})
            # Note: If using IP similarity with normalized vectors, score nearer to 1 means high similarity.
        conn.close()
        return results
