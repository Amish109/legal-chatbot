# rag.py
from typing import List, Dict, Any, Optional
import numpy as np
from embedder_import_fix import Embedder  # to satisfy import-time ordering in single-file context
# Note: Replace with real import or use below import
# from embedding import Embedder
from embedding import Embedder
from ollama_client import OllamaClient
from vectorstore import VectorStore
from ethical import EthicalFilter

SYSTEM_PROMPT = """
You are a legal assistant specialized in Indian law. Answer in clear, simple language suitable for a general audience.
- If a user's question references a user-uploaded document, cite the source and which part if relevant.
- If the user asks anything illegal or unethical, refuse politely and explain why.
- If unsure about factual legal advice, suggest contacting a qualified lawyer and provide next steps.
"""

class RAG:
    def __init__(self, ollama_client: OllamaClient, embedder: Embedder, vector_store: VectorStore, ethical_filter: EthicalFilter):
        self.ollama = ollama_client
        self.embedder = embedder
        self.vs = vector_store
        self.ethical = ethical_filter

    def answer(self, query: str, session_id: str, namespace: str = "global", top_k: int = 5) -> (str, List[Dict[str,Any]]):
        # embed query
        q_emb = self.embedder.embed([query])
        # normalize
        q_emb = q_emb / np.linalg.norm(q_emb, axis=1, keepdims=True)

        # retrieve
        docs = self.vs.search(namespace=namespace, query_emb=q_emb[0], top_k=top_k)
        # assemble context
        context_texts = []
        sources = []
        for d in docs:
            snippet = d["text"]
            context_texts.append(f"SOURCE: {d['meta'].get('source','unknown')} PART:{d['meta'].get('part','?')}\n{snippet}")
            sources.append(d.get("meta", {}))

        # build prompt
        messages = []
        messages.append({"role": "system", "content": SYSTEM_PROMPT})
        if context_texts:
            # include retrieved context
            messages.append({"role": "system", "content": "Use the following retrieved documents to answer the question:\n\n" + "\n\n---\n\n".join(context_texts)})
        messages.append({"role": "user", "content": query})
        # call ethical filter again for final answer generation
        decision = self.ethical.check_text(query)
        if decision.block:
            raise Exception("Blocked by ethical filter: " + decision.reason)

        # ask ollama
        response = self.ollama.chat(system=SYSTEM_PROMPT, messages=messages, temperature=0.0, max_tokens=800)
        return response, sources
