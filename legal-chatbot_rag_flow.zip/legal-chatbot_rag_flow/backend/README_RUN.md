Quick start:

1. Install requirements:
   pip install -r requirements.txt

2. Ensure Ollama is installed & running locally, and you have a model available (set OLLAMA_MODEL env var if different).
   Optionally set OLLAMA_API_URL if your Ollama HTTP API runs on a different host/port.

3. (Optional) Set REDIS_URL to use Redis for session persistence.

4. Prepare a folder with global legal texts (plain text, pdf, docx). Then:
   POST /kb/build_global with JSON body {"folder_path": "/path/to/legal_texts_folder"}
   or call the endpoint via curl: curl -X POST "http://localhost:8000/kb/build_global?folder_path=/abs/path"

5. Start the app:
   uvicorn main:app --reload --port 8000

6. Upload user docs:
   POST /upload?user_id=123 with form-file to upload and index user documents.

7. Chat:
   POST /chat with JSON {"user_id":"123","message":"does this contract violate any clause?"}
