# parsers.py
import fitz  # PyMuPDF
import docx2txt
import os

def extract_text_from_file(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        return extract_text_pdf(path)
    elif ext in (".docx", ".doc"):
        return extract_text_docx(path)
    elif ext in (".txt",):
        return extract_text_txt(path)
    else:
        # try best-effort
        try:
            return extract_text_txt(path)
        except:
            return ""

def extract_text_pdf(path: str) -> str:
    doc = fitz.open(path)
    pages = []
    for p in doc:
        pages.append(p.get_text())
    return "\n".join(pages)

def extract_text_docx(path: str) -> str:
    return docx2txt.process(path) or ""

def extract_text_txt(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()
