# utils.py
from typing import List
import re

def chunk_text(text: str, max_chars: int = 1500) -> List[str]:
    """
    Rudimentary text chunker: splits on paragraphs and sentences to create
    chunks of approx max_chars characters.
    """
    paragraphs = [p.strip() for p in re.split(r'\n{1,}', text) if p.strip()]
    chunks = []
    current = ""
    for p in paragraphs:
        if len(current) + len(p) + 1 <= max_chars:
            current = current + "\n\n" + p if current else p
        else:
            if current:
                chunks.append(current)
            # if paragraph itself too big, split by sentences
            if len(p) > max_chars:
                import nltk
                try:
                    from nltk import sent_tokenize
                except Exception:
                    # fallback naive split
                    sents = [p[i:i+max_chars] for i in range(0, len(p), max_chars)]
                    chunks.extend(sents)
                    current = ""
                    continue
                sents = sent_tokenize(p)
                cur2 = ""
                for s in sents:
                    if len(cur2) + len(s) + 1 <= max_chars:
                        cur2 = cur2 + " " + s if cur2 else s
                    else:
                        chunks.append(cur2)
                        cur2 = s
                if cur2:
                    current = cur2
                else:
                    current = ""
            else:
                current = p
    if current:
        chunks.append(current)
    return chunks
