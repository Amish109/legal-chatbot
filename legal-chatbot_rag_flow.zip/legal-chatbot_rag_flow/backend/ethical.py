# ethical.py
from typing import List, Optional
import re
from dataclasses import dataclass

@dataclass
class EthicalDecision:
    block: bool
    reason: Optional[str] = None

class EthicalFilter:
    """
    Basic ethical filter:
      - pattern-based blocking for obviously illegal or harmful intents.
      - for ambiguous cases it can return 'review' (not implemented) or rely on the LLM.
    """

    BLOCK_PATTERNS = [
        r"\bhow to rob\b", r"\bhow to make a bomb\b", r"\bkill\b", r"\bassassinat", r"\bexplosive\b",
        r"\bdestroy\b", r"\bpoison\b", r"\bwizardry\b", r"\bgain unauthorized\b", r"\bhack\b",
        r"\bdisable CCTV\b", r"\bsteal\b", r"\bbypass security\b", r"\bfake diploma\b", r"\bforgery\b",
    ]

    def __init__(self, ollama_client=None):
        self.patterns = [re.compile(pat, re.I) for pat in self.BLOCK_PATTERNS]
        self.ollama = ollama_client

    def check_text(self, text: str) -> EthicalDecision:
        t = text.lower()
        for pat in self.patterns:
            if pat.search(t):
                return EthicalDecision(block=True, reason="Request involves illegal or harmful activity — cannot assist.")
        # also refuse instructions that explicitly encourage evading law or hurting people
        if any(word in t for word in ["evade", "how to avoid police", "avoid arrest", "how to launder"]):
            return EthicalDecision(block=True, reason="Request involves evading law or illegal activity — cannot assist.")
        # otherwise allow
        return EthicalDecision(block=False)
